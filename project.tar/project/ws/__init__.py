from fastapi import APIRouter

ws_router = APIRouter()

from . import views  # noqa
